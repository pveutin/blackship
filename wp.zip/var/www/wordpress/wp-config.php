<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier contient les réglages de configuration suivants : réglages MySQL,
 * préfixe de table, clés secrètes, langue utilisée, et ABSPATH.
 * Vous pouvez en savoir plus à leur sujet en allant sur
 * {@link http://codex.wordpress.org/fr:Modifier_wp-config.php Modifier
 * wp-config.php}. C’est votre hébergeur qui doit vous donner vos
 * codes MySQL.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define( 'DB_NAME', 'blacksheep' );

/** Utilisateur de la base de données MySQL. */
define( 'DB_USER', 'root' );

/** Mot de passe de la base de données MySQL. */
define( 'DB_PASSWORD', 'root' );

/** Adresse de l’hébergement MySQL. */
define( 'DB_HOST', 'localhost' );

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Type de collation de la base de données.
  * N’y touchez que si vous savez ce que vous faites.
  */
define('DB_COLLATE', '');

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clefs secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'npBi,Z.UAkj>[X>9zaA)WcDNu61tA)1!Ee6_Y(;gs`-amrrP5O^nP]YSLD)w+_%i' );
define( 'SECURE_AUTH_KEY',  'JMb{ZM$J)|[OCII[U>i9Xp{^v;ujsY(Le8u4dH=cokskj-tQQF~/}]P>te8G@mLC' );
define( 'LOGGED_IN_KEY',    '9:tq`4T0>kK*`gy9Zn-zELI|(qoq/p4XACx)w+.^+kbzG:%|5C+LKw8yJmq}7zm?' );
define( 'NONCE_KEY',        '9xUP?<iUH}@<gd& <%Cpp4H$t_]i+15U;8PU_cA;4M&lT/uoMkEicbtV@BUg <?]' );
define( 'AUTH_SALT',        '>c&Ppw7Q&r;)6_dmbGnK]7yc~1WxUj_R^n5sRBfMkXets@t*Jry=baMHWSVW{Sn1' );
define( 'SECURE_AUTH_SALT', 'S3Pa!O=tV-0a=Z1wGKEp1Pgq6H0@&ZS:qM]&dgs@>quQooT}I,W?W)MKX{kPn3-C' );
define( 'LOGGED_IN_SALT',   'Q.b%Rt%H3M5(DX?0zh:OY5%J?puT]G%a&#rD;u-xC2*[(g7nV;B6Tp79kb&3$3/:' );
define( 'NONCE_SALT',       '!qI>hY!2rV#PVS@;[9I@Uhtr25y}rbFBd9x1t_TN1^6rS,tf(xt%tgBmv.M+Fr;]' );
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix = 'wp_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortemment recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* C’est tout, ne touchez pas à ce qui suit ! Bonne publication. */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');
